package Repository;

import Entity.NhanVien;
import Util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.ArrayList;

public class NhanVienRepository {
    public ArrayList<NhanVien> getAll(){
        ArrayList<NhanVien> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            list = (ArrayList<NhanVien>) session.createQuery("from NhanVien ").list();
        } catch (Exception e){
            e.printStackTrace();
        }

        return list;
    }

    public NhanVien getById(String id){
        NhanVien result = new NhanVien();
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            result = session.get(NhanVien.class, id);
        } catch (Exception e){
            e.printStackTrace();
        }

        return result;
    }

    public Boolean delete(NhanVien nhanVien){
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            session.delete(nhanVien);
            transaction.commit();

            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public Boolean add(NhanVien nhanVien){
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            session.save(nhanVien);
            transaction.commit();

            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

}
