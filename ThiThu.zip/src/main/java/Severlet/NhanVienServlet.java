package Severlet;

import Entity.NhanVien;
import Repository.NhanVienRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

@WebServlet(name = "NhanVienServlet", value ={
        "/nhan-vien/hien-thi",
        "/nhan-vien/add",
        "/nhan-vien/detail",
        "/nhan-vien/delete",
})

public class NhanVienServlet extends HttpServlet {

    private NhanVienRepository repository = new NhanVienRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("/hien-thi")){
            ArrayList<NhanVien> list = repository.getAll();
            request.setAttribute("list", list);
            request.getRequestDispatcher("/nhan-vien.jsp").forward(request, response);
        } else if (uri.contains("/delete")){
            String id = request.getParameter("id");
            NhanVien nhanVien = repository.getById(id);
            repository.delete(nhanVien);
            response.sendRedirect("/nhan-vien/hien-thi");
        } else {
            String id = request.getParameter("id");
            NhanVien nhanVien = repository.getById(id);
            request.setAttribute("detail", nhanVien);

            ArrayList<NhanVien> list = repository.getAll();
            request.setAttribute("list", list);
            request.getRequestDispatcher("/nhan-vien.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("/add")){
            NhanVien nhanVien = new NhanVien();
            try {
                BeanUtils.populate(nhanVien, request.getParameterMap());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();

            }
            repository.add(nhanVien);
            response.sendRedirect("/nhan-vien/hien-thi");
        }
    }
}
