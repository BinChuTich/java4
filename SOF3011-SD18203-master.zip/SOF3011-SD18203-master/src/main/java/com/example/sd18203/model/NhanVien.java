package com.example.sd18203.model;

public class NhanVien {
    
    private String id;

    private String hoTen;

    private String gioiTinh;

    private String diaChi;

    private String trangThai;

    private String phongBan;

    private Integer luong;
}
