package com.example.ASMJAVA4.service.impl;

;

import com.example.ASMJAVA4.entity.SanPham;
import com.example.ASMJAVA4.repositoty.SanPhamRepository;
import com.example.ASMJAVA4.service.SanPhamService;

import java.util.List;

public class SanPhamServiceImpl implements SanPhamService {
    private SanPhamRepository sanPhamRepository = new SanPhamRepository();

    @Override
    public List<SanPham> getAll() {
        return sanPhamRepository.getAll();
    }

    @Override
    public Boolean add(SanPham sanPham) {
        return sanPhamRepository.add(sanPham);
    }

    @Override
    public Boolean remove(SanPham sanPham) {
        return sanPhamRepository.remove(sanPham);
    }

    @Override
    public Boolean update(SanPham sanPham) {
        return sanPhamRepository.update(sanPham);
    }

    @Override
    public SanPham getOne(String idParam) {
        return sanPhamRepository.getOne(idParam);
    }
}
