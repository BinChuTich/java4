package com.example.ASMJAVA4.service;



import com.example.ASMJAVA4.entity.ChucVu;

import java.util.List;

public interface ChucVuService {
    List<ChucVu> getAll();

    Boolean add(ChucVu chucVu);

    Boolean remove(ChucVu chucVu);

    List<ChucVu> searchName(String ma);

    Boolean update(ChucVu chucVu);

    ChucVu getOne(String idParam);
}
