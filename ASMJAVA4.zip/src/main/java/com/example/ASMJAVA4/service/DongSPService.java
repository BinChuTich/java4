package com.example.ASMJAVA4.service;

import com.example.ASMJAVA4.entity.DongSP;


import java.util.List;

public interface DongSPService {
    List<DongSP> getAll();

    Boolean add(DongSP dongSP);

    Boolean remove(DongSP dongSP);

    Boolean update(DongSP dongSP);

    DongSP getOne(String idParam);
}
