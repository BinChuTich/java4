package com.example.ASMJAVA4.service.impl;



import com.example.ASMJAVA4.entity.NSX;
import com.example.ASMJAVA4.repositoty.NSXRepository;
import com.example.ASMJAVA4.service.NSXService;

import java.util.List;

public class NSXServiceImpl implements NSXService {
    private NSXRepository nsxRepository = new NSXRepository();

    @Override
    public List<NSX> getAll() {
        return nsxRepository.getAll();
    }

    @Override
    public Boolean add(NSX nsx) {
        return nsxRepository.add(nsx);
    }

    @Override
    public Boolean remove(NSX nsx) {
        return nsxRepository.remove(nsx);
    }

    @Override
    public Boolean update(NSX nsx) {
        return nsxRepository.update(nsx);
    }

    @Override
    public NSX getOne(String idParam) {
        return nsxRepository.getOne(idParam);
    }
}
