package com.example.ASMJAVA4.service;



import com.example.ASMJAVA4.entity.NhanVien;

import java.util.List;

public interface NhanVienService {
    List<NhanVien> getAll();

    Boolean add(NhanVien nhanVien);

    Boolean remove(NhanVien nv);

    List<NhanVien> searchName(String ma);

    Boolean update(NhanVien nhanVien);

    NhanVien getOne(String idParam);
}
