package com.example.ASMJAVA4.service;



import com.example.ASMJAVA4.entity.KhachHang;

import java.util.List;

public interface KhachHangService {
    List<KhachHang> getAll();

    Boolean add(KhachHang kh);

    Boolean remove(KhachHang kh);

    KhachHang detail(String ma);

    List<KhachHang> searchName(String ma);

    Boolean update(KhachHang kh);

    KhachHang getOne(String idParam);
}
