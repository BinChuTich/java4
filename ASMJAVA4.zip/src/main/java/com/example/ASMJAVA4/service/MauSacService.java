package com.example.ASMJAVA4.service;



import com.example.ASMJAVA4.entity.MauSac;

import java.util.List;

public interface MauSacService {
    List<MauSac> getAll();

    Boolean add(MauSac mauSac);

    Boolean remove(MauSac mauSac);

    Boolean update(MauSac mauSac);

    MauSac getOne(String idParam);
}
