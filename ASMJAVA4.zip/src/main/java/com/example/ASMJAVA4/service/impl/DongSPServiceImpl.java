package com.example.ASMJAVA4.service.impl;



import com.example.ASMJAVA4.entity.DongSP;
import com.example.ASMJAVA4.repositoty.DongSPRepository;
import com.example.ASMJAVA4.service.DongSPService;

import java.util.List;

public class DongSPServiceImpl implements DongSPService {
    private DongSPRepository dongSPRepository = new DongSPRepository();

    @Override
    public List<DongSP> getAll() {
        return dongSPRepository.getAll();
    }

    @Override
    public Boolean add(DongSP dongSP) {
        return dongSPRepository.add(dongSP);
    }

    @Override
    public Boolean remove(DongSP dongSP) {
        return dongSPRepository.remove(dongSP);
    }

    @Override
    public Boolean update(DongSP dongSP) {
        return dongSPRepository.update(dongSP);
    }

    @Override
    public DongSP getOne(String idParam) {
        return dongSPRepository.getOne(idParam);
    }
}
