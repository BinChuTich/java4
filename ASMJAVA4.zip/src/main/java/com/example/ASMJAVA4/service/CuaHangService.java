package com.example.ASMJAVA4.service;



import com.example.ASMJAVA4.entity.CuaHang;

import java.util.List;

public interface CuaHangService {
    List<CuaHang> getAll();

    Boolean add(CuaHang cuaHang);

    Boolean remove(CuaHang cuaHang);

    List<CuaHang> searchName(String ma);

    Boolean update(CuaHang cuaHang);

    CuaHang getOne(String idParam);
}
