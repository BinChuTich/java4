package com.example.ASMJAVA4.service.impl;

import com.example.ASMJAVA4.entity.KhachHang;
import com.example.ASMJAVA4.repositoty.KhachHangRepository;
import com.example.ASMJAVA4.service.KhachHangService;

import java.util.List;

public class KhachHangServiceImpl implements KhachHangService {
    private KhachHangRepository khachHangRepository = new KhachHangRepository();

    @Override
    public List<KhachHang> getAll() {
        return khachHangRepository.getAll();
    }

    @Override
    public Boolean add(KhachHang kh) {
        return khachHangRepository.add(kh);
    }

    @Override
    public Boolean remove(KhachHang kh) {
        return khachHangRepository.remove(kh);
    }

    @Override
    public KhachHang detail(String ma) {
        return khachHangRepository.getOne(ma);
    }

    @Override
    public List<KhachHang> searchName(String tenParam) {
        return khachHangRepository.filterByName(tenParam);
    }

    @Override
    public Boolean update(KhachHang kh) {
        return khachHangRepository.update(kh);
    }

    @Override
    public KhachHang getOne(String idParam) {
        return khachHangRepository.getOne(idParam);
    }
}
