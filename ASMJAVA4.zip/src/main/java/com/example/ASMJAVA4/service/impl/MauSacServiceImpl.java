package com.example.ASMJAVA4.service.impl;


import com.example.ASMJAVA4.entity.MauSac;
import com.example.ASMJAVA4.repositoty.MauSacRepository;
import com.example.ASMJAVA4.service.MauSacService;

import java.util.List;

public class MauSacServiceImpl implements MauSacService {
    private MauSacRepository mauSacRepository = new MauSacRepository();

    @Override
    public List<MauSac> getAll() {
        return mauSacRepository.getAll();
    }

    @Override
    public Boolean add(MauSac mauSac) {
        return mauSacRepository.add(mauSac);
    }

    @Override
    public Boolean remove(MauSac mauSac) {
        return mauSacRepository.remove(mauSac);
    }

    @Override
    public Boolean update(MauSac mauSac) {
        return mauSacRepository.update(mauSac);
    }

    @Override
    public MauSac getOne(String idParam) {
        return mauSacRepository.getOne(idParam);
    }
}
