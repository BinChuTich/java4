package com.example.ASMJAVA4.controller;


import com.example.ASMJAVA4.entity.ChucVu;
import com.example.ASMJAVA4.entity.CuaHang;
import com.example.ASMJAVA4.entity.NhanVien;
import com.example.ASMJAVA4.service.ChucVuService;
import com.example.ASMJAVA4.service.CuaHangService;
import com.example.ASMJAVA4.service.NhanVienService;
import com.example.ASMJAVA4.service.impl.ChucVuServiceImpl;
import com.example.ASMJAVA4.service.impl.CuaHangServiceImpl;
import com.example.ASMJAVA4.service.impl.NhanVienServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/nhan-vien/*")
public class NhanVienServlet extends HttpServlet {
    private NhanVienService nhanVienService = new NhanVienServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        if (action == null) {
            action = "/hien-thi-danh-sach";
        }

        switch (action) {
            case "/hien-thi-danh-sach":
                hienThiDanhSach(req, resp);
                break;
            case "/hien-thi-chi-tiet":
                hienThiChiTiet(req, resp);
                break;
            case "/tim-kiem":
                timKiemNhanVien(req, resp);
                break;
            case "/hien-thi-cap-nhat":
                hienThiCapNhat(req, resp);
                break;
            case "/hien-thi-them":
                hienThiThem(req, resp);
                break;
            case "/xoa-nhan-vien":
                xoaNhanVien(req, resp);
                break;
            default:
                resp.sendRedirect("/nhan-vien/hien-thi-danh-sach");
        }
    }

    private void hienThiDanhSach(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<NhanVien> nhanVienList = nhanVienService.getAll();
        req.setAttribute("nhanVien", nhanVienList);
        req.getRequestDispatcher("/view/NhanVien/NhanVien.jsp").forward(req, resp);
    }

    private void hienThiChiTiet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("DetailId");
        NhanVien nhanVien = nhanVienService.getOne(idParam);
        req.setAttribute("nvv", nhanVien);

        hienThiDanhSach(req, resp);
    }

    private void timKiemNhanVien(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String tenParam = req.getParameter("ten");
        List<NhanVien> nhanVienList = nhanVienService.searchName(tenParam);
        req.setAttribute("nhanVien", nhanVienList);
        req.getRequestDispatcher("/view/NhanVien/NhanVien.jsp").forward(req, resp);
    }

    private void hienThiCapNhat(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("UpdateId");
        NhanVien nhanVien = nhanVienService.getOne(idParam);
        req.setAttribute("nvu", nhanVien);
        req.getRequestDispatcher("/view/NhanVien/CapNhatNhanVien.jsp").forward(req, resp);
    }

    private void hienThiThem(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/view/NhanVien/ThemNhanVien.jsp").forward(req, resp);
    }

    private void xoaNhanVien(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String maParam = req.getParameter("DeleteId");
        NhanVien nhanVien = nhanVienService.getOne(maParam);
        if (nhanVien != null) {
            nhanVienService.remove(nhanVien);
        }
        resp.sendRedirect("/nhan-vien/hien-thi-danh-sach");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        if (action == null) {
            action = "/hien-thi-danh-sach";
        }

        switch (action) {
            case "/them-nhan-vien":
                themNhanVien(req, resp);
                break;
            case "/cap-nhat-nhan-vien":
                capNhatNhanVien(req, resp);
                break;
            default:
                resp.sendRedirect("/nhan-vien/hien-thi-danh-sach");
        }
    }

    private void themNhanVien(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String maParam = req.getParameter("ma");
        String tenParam = req.getParameter("ten");
        String tenDemParam = req.getParameter("tenDem");
        String hoParam = req.getParameter("ho");
        String ngaySinhParam = req.getParameter("ngaySinh");
        String diaChiParam = req.getParameter("diaChi");
        String sdtParam = req.getParameter("sdt");

        String matKhauParam = req.getParameter("matKhau");
        String idCH = req.getParameter("idCH");
        String idCV = req.getParameter("idCV");
        String idGuiBC = req.getParameter("idGuiBC");
        String trangThaiParam = req.getParameter("trangThai");

        NhanVien nhanVien = NhanVien.builder()
                .ma(maParam)
                .ten(tenParam)
                .tenDem(tenDemParam)
                .ho(hoParam)
                .ngaySinh(ngaySinhParam)
                .diaChi(diaChiParam)
                .sdt(sdtParam)
                .matKhau(matKhauParam)
                .idCH(idCH)
                .idCV(idCV)
                .idGuiBC(idGuiBC)

                .trangThai(trangThaiParam)
                .build();
        nhanVienService.add(nhanVien);
        resp.sendRedirect("/nhan-vien/hien-thi-danh-sach");

    }

    private void capNhatNhanVien(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        String ma = req.getParameter("ma");
        String ten = req.getParameter("ten");
        String tenDem = req.getParameter("tenDem");
        String ho = req.getParameter("ho");
        String ngaySinh = req.getParameter("ngaySinh");
        String diaChi = req.getParameter("diaChi");
        String sdt = req.getParameter("sdt");
        String matKhau = req.getParameter("matKhau");
        String idCH = req.getParameter("idCH");
        String idCV = req.getParameter("idCV");
        String idGuiBC = req.getParameter("idGuiBC");
        String trangThai = req.getParameter("trangThai");


        NhanVien nhanVien = NhanVien.builder()
                .id(id)
                .ma(ma)
                .ten(ten)
                .tenDem(tenDem)
                .ho(ho)
                .ngaySinh(ngaySinh)
                .diaChi(diaChi)
                .sdt(sdt)
                .matKhau(matKhau)
                .idCH(idCH)
                .idCV(idCV)
                .idGuiBC(idGuiBC)
                .trangThai(trangThai)
                .build();

        nhanVienService.update(nhanVien);

        resp.sendRedirect("/nhan-vien/hien-thi-danh-sach");
    }
}
